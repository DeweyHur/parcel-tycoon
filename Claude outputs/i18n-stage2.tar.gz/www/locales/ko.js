// 한국어 (기본 언어). 구조: name / ui(키 → 문자열) / data(DATA 텍스트 오버레이) / meta(META 텍스트 오버레이)
// 자리표시자: {name} 치환, {n:개|개} 형태는 n이 1이면 앞, 아니면 뒤 (#는 숫자로 치환)
(function (root) {
  const L = {
  name: '한국어',
  ui: {
    // ----- 게임 코어: 로그 (log.*) · 오류 (err.*) · 페널티 사유 (r.*) · 폐기 사유 (why.*) · 게임오버 (over.*) -----
    'log.monthStart': '── {m}개월차 시작 ──',
    'log.prepMarket': '준비 마켓: 1개월차 시작 전 구매 (새로고침 1회 무료)',
    'log.bigCustomer': '대형 계약: {name}이(가) 물량 60%를 보냅니다',
    'log.custSuspend': '{name} 거래 중단 ({why}) — 다음 달 재개',
    'log.custResume': '{name} 거래 재개',
    'log.custLevel': '{name} 신뢰 {level}단계!',
    'log.claim': '손해배상 -{amount}c ({name}, {why}{covered})',
    'log.claimCovered': ', 보험 {covered}c 보장',
    'log.insurerChange': '보험 변경: {name}{fee}',
    'log.insurerFee': ' (가입비 -{cost}c)',
    'log.storageOffer': '보관 제안: {name} {kind} {vol}칸 · {turns}턴 · {pay}',
    'log.storagePrepaid': '선불 {fee}c',
    'log.storagePerTurn': '턴당 {perTurn}c 후불',
    'log.storageAccept': '보관 수락: {kind} {vol}칸 (+{fee}c)',
    'log.storageDecline': '보관 제안 거절',
    'log.storageEarlyReturn': '보관 조기 반환: 환불 {refund}c + 위약금 {pen}c',
    'log.storageCollect': '보관 회수: {kind}{pay}',
    'log.storagePostpaid': ' (+{pay}c 후불)',
    'log.offerExpired': '보관 제안 만료',
    'log.strike': '⚠ 이번 달 {name} 파업: 호출 불가',
    'log.paid': '{name} 입금 +{amount}c ({count}개)',
    'log.heatAlert': ' 🌡폭염 경보!',
    'log.arrive': '{month}월 {turn}턴: {list} 입고 (사용률 {usage}%){note}',
    'log.wait': '대기: 호출 없이 1턴 진행',
    'log.waitSelf': '대기 + 직접 배송 {count}개 (+{revenue}c, 배송비 -{cost}c)',
    'log.transitCert': '운송 보험증 사용: 이번 호출 파손 없음',
    'log.callAllBroken': '{name} 호출: {broken}개 전부 파손!',
    'log.trustUp': '{name} 신뢰도 {level}단계 달성! ({effect})',
    'log.spareCall': '예비 기사 투입 (잔여 호출 없이 호출)',
    'log.call': '{name} 호출: {count}개 처리, +{revenue}c{delay}{broken}{refund} (잔여 {calls}회){instant}',
    'log.callDelay': ' ({delay}턴 뒤 입금)',
    'log.callBroken': ', 파손 {broken}개',
    'log.callRefund': ' (묶음 할인: 호출 미소모)',
    'log.callInstant': ' ⚡즉시',
    'log.discard': '폐기: {short}{size} — {why}{pen}',
    'log.penalty': '페널티 +{pen}: {reasons} (스트레스 {stress})',
    'log.erosion': '불안정: {name} 잔여 호출 -1',
    'log.settle': '{month}월 정산: 수익 {revenue}, 운영비 {opCost}{closing}',
    'log.settleClosing': ', 월말 결산 +{closing}',
    'log.gameOver': '게임오버: {reason}',
    'log.marketOpen': '{month}월 마켓 오픈 (최대 {max}개 구매)',
    'log.refresh': '마켓 새로고침 (-{cost}c)',
    'log.refreshFree': '마켓 새로고침 (무료)',
    'log.buyContract': '계약 구매: {name} (-{price}c){old}',
    'log.buyContractOld': ', {name} 폐기 (잔여 {calls}회 소멸)',
    'log.enhance': '강화 적용: {name} → {contract} (-{price}c)',
    'log.buyCustomer': '신규 고객 계약: {name} (-{price}c)',
    'log.buyItem': '구매: {name} (-{price}c)',
    'log.buyFacility': '시설 구매: {name} (-{price}c)',
    'r.wet': '젖음 {short}{size}',
    'r.heatProduce': '폭염에 농산물 상함 {short}{size} 기한 -2',
    'r.overdue': '기한 초과 {short}',
    'r.overdueCont': '초과 지속 {short}',
    'r.discard': '{why} 폐기 {short}',
    'r.returned': '반송 {short}{pen}',
    'r.returnedInsured': '반송 (보험 적용)',
    'r.stolen': '도난 {short}{size} +2',
    'r.stolenInsured': '도난 (보험 적용)',
    'r.storageStolen': '보관 물품 도난 +2 (배상 {amount}c)',
    'r.overflow': '창고 초과 {over} (+{pen})',
    'r.overflowGrace': '창고 초과 {over} (임시 적재장)',
    'why.delivered': '처리',
    'why.noClaim': '무사고',
    'why.fanInsurer': '선호 보험',
    'why.earlyReturn': '조기 반환',
    'why.storageDone': '보관 완료',
    'why.storageStolen': '보관 도난',
    'why.noFrozenZone': '냉동 구역 없음',
    'why.outsideFrozen': '냉동 구역 밖',
    'why.heatSpoil': '폭염 부패',
    'why.warmSpoil': '상온 부패',
    'why.brokenInTransit': '{name} 운송 중 파손',
    'why.returned': '반송',
    'why.stolen': '도난',
    'why.insured': '{why} (보험 적용)',
    'over.stress': '운영 스트레스가 한계에 도달했습니다',
    'over.bankrupt': '운영비를 지불하지 못해 파산했습니다',
    'over.delivered': '처리량 부족: {n}/{need}개',
    'over.discard': '부패 폐기 초과: {n}개 (허용 {max})',
    'over.cash': '자금 부족: {cash}/{need}c',
    'over.overdue': '기한 초과 처리 초과: {n}개 (허용 {max})',
    'over.storage': '보관 계약 부족: {n}/{need}건',
    'over.bigCustomer': '{name} 신뢰 {level}단계 (3단계 필요)',
    'over.win': '{months}개월 생존 성공!',
    'err.noCash': '자금이 부족합니다',
    'err.marketOnly': '마켓에서만 바꿀 수 있습니다',
    'err.noInsurer': '없는 보험사',
    'err.alreadyInsured': '이미 가입 중',
    'err.startupNoInsurance': '스타트업은 첫 달 무보험 (2개월차 마켓부터 가입)',
    'err.noOffer': '제안이 없습니다',
    'err.offerTooBig': '창고보다 큽니다',
    'err.noStorage': '없는 보관 계약',
    'err.needRefundPenalty': '환불+위약금 {cost}c가 필요합니다',
    'err.cannotCallNow': '지금은 호출할 수 없습니다',
    'err.emptySlot': '빈 슬롯',
    'err.struck': '파업 중인 업체입니다',
    'err.noCalls': '잔여 호출 횟수가 없습니다',
    'err.overCap': '최대 {cap}개까지 처리할 수 있습니다',
    'err.nothingToShip': '처리할 택배가 없습니다',
    'err.cannotShipNow': '지금은 배송할 수 없습니다',
    'err.nothingSelf': '직접 배송할 수 있는 택배가 없습니다',
    'err.selfLimit': '직접 배송은 한 턴에 {n}개까지',
    'err.selfCost': '배송비 {cost}c가 부족합니다',
    'err.noRefresh': '이 시나리오에서는 새로고침할 수 없습니다',
    'err.notMarket': '마켓이 아닙니다',
    'err.sold': '이미 판매된 상품',
    'err.marketMax': '한 달에 {n}개까지만 구매할 수 있습니다',
    'err.pickSlot': '교체할 슬롯을 선택하세요',
    'err.pickContract': '적용할 계약을 선택하세요',
    'err.limitMax': '호출 한도 강화는 계약당 2회까지',
    'err.capMax': '처리 용량 강화는 계약당 3단계까지',
    'err.hasRegular': '이미 정기 배차가 적용된 계약',
    'err.hasExpress': '이미 고속 배차가 적용된 계약',
    'err.optOne': '특약은 계약당 1개',
    'err.optHasAttr': '이미 그 속성을 다루는 업체',
    'err.optUrgent': '긴급 특송에는 특약을 붙일 수 없음',
    'err.optSize': '크기 최대 {max} 이하 계약만',
    'err.optPlain': '속성 없는 택배 전용 업체에는 붙일 수 없음',
    'err.customerMax': '고객은 {n}명까지',
    'err.customerDup': '이미 거래 중인 고객',
    'err.soldOut': '매진',
    'xp.base': '정상 처리 +1',
    'xp.cap80': '처리량 80%↑ +1',
    'xp.specialist': '전문 처리 +1',
    'xp.coldChain': '콜드체인 +1',
    'note.regular': '정기 배차 +1',
    'note.express': '고속 배차 +1',
    'note.trust2': '신뢰 2단계 +1',
    'note.skip': '스킵 보너스 +1',
    'note.waitStack': '대기 누적 +{n}',
    'note.firstCall': '동네 단골 +1',
    'self.needBigVan': '대형 트럭 필요',
    'self.needColdVan': '냉동 탑차 필요',
    'self.needPadVan': '완충 포장차 필요',
    'self.customsWait': '통관 대기 중',
    'market.hint': '창고의 {short} {count}개 처리 가능',
    'market.facSoldOut': '시설 매진',
    'market.newCustomer': '신규 고객: {name}',
    'trust.l3prefix': '신뢰 3단계: ',

    // ----- UI (ui.js / index.html) — 아래에 추가 -----
    'ach.done': '🏆 도전과제 달성: {name}',
    'ach.unlock': '🔓 해금: {name}',
    'btn.ok': '확인',
    'btn.cancel': '취소',
    'title.name': '택배 타이쿤',
    'title.sub': '턴제 물류 경영 로그라이크 · 프로토타입',
    'title.continue': '이어하기',
    'fmt.monthTurn': '{m}개월차 {t}턴',
    'title.new': '새 런 시작',
    'title.codex': '도감',
    'title.codexSub': '{a}/{b} 해금 · 도전과제 {c}/{d}',
    'title.records': '기록',
    'title.recordsSub': '최고 {best}점 · {w}승 {l}패',
    'title.help': '게임 방법',
    'opt.sound': '효과음: {v}',
    'opt.music': '음악: {v}',
    'opt.lang': '언어',
    'title.modal': '택배 회사 게임',
    'title.confirmNew': '진행 중인 런이 있습니다. 새로 시작하면 사라집니다. 계속할까요?',
    'title.newShort': '새로 시작',
    'opt.on': '켜짐',
    'opt.off': '꺼짐',
    'prep.today': '오늘',
    'prep.dailyDone': '오늘 기록 완료',
    'prep.win': '승리',
    'prep.recommend': '추천',
    'prep.dailyNormal': '데일리는 정규 고정',
    'prep.scenarioTitle': '시나리오 선택',
    'prep.step1': '1/3 단계 — 런의 길이와 규칙을 고릅니다',
    'btn.title': '타이틀',
    'prep.nextCompany': '다음: 회사',
    'prep.warehouse': '용량 {cap} · 냉장 {cold} · 초대형 {xl}',
    'prep.warehouseRandom': '창고 무작위',
    'prep.contractsRandom': '계약 무작위 4개',
    'hud.cash': '자금',
    'prep.contracts': '계약',
    'prep.companyTitle': '회사 선택',
    'prep.step2': '2/3 단계',
    'btn.back': '이전',
    'prep.nextPerk': '다음: 퍽',
    'prep.noColdCompany': '냉장 구역이 없는 회사',
    'prep.sameFamily': '같은 계열({family}) 퍽 장착 중',
    'prep.step3': '3/3 단계',
    'prep.variants': '변형',
    'prep.perkCount': '퍽 {n}/{slots} (같은 계열은 하나만)',
    'prep.insuranceHead': '보험 (월 보험료는 월말 정산에서 차감, 무사고면 다음 달 -20%)',
    'prep.startupNoIns': '스타트업은 무보험으로 시작합니다. 2개월차 마켓부터 가입 가능',
    'prep.fans': '선호 고객: {list} (가입 중 월초 xp +1)',
    'prep.perkTitle': '퍽 장착',
    'prep.start': '런 시작',
    'tier.0': '시작',
    'tier.1': '1단계 · 기본',
    'tier.2': '2단계 · 특화 누적',
    'tier.3': '3단계 · 도전',
    'fmt.months': '{n}개월',
    'fmt.pts': '{n}점',
    'fmt.calls': '{n}회',
    'fmt.perMonth': '월 {n}c',
    'fmt.count': '{n}개',
    'fmt.turns': '{n}턴',
    'fmt.turnN': '{n}턴',
    'fmt.level': '{n}단계',
    'fmt.cells': '{n}칸',
    'prep.family': '{family} 계열',
    'prep.slotFull': '퍽 슬롯은 {n}개입니다',
    'fmt.monthN': '{n}개월차',
    'hud.turn': '{t}/{max}턴',
    'hud.strike': '파업',
    'hud.familyPerk': '{family} 계열 퍽',
    'hud.upcoming': '입고 예정',
    'hud.monthEnd': '월말 정산',
    'hud.outdoor': '🌧 야외 {vol}칸 ({n}개{storage}) · 이번 턴 도난 {pct}%',
    'hud.outdoorStorage': '+보관',
    'hud.outdoorTag': '🌧 야외',
    'hud.outdoorLabel': '야외',
    'storage.left': '회수까지 {n}턴',
    'hud.buyInMarket': '마켓에서 계약을 구매하세요',
    'hud.spare': '예비',
    'hud.contractSub': '<b>{cap}</b>개 · 대상 <b>{elig}</b>',
    'hud.noTurn': '턴 미소모',
    'hud.regular': '정기',
    'hud.express': '고속',
    'wait.overdue': '⏳초과 {n}',
    'wait.spoil': '🥀부패 {n}',
    'wait.frozenOver': '❆냉동 자리 없음 {n}',
    'wait.btn': '⏭ 대기 · 직접 배송',
    'wait.next': '다음 턴 창고 {used}/{cap}{over}',
    'wait.over': ' 초과!',
    'cust.trustLv': '신뢰 {n}단계',
    'cust.suspended': '중단',
    'company.difficulty': '난이도',
    'company.warehouse': '창고 {cap} · 냉장 {cold} · 냉동 {frozen} · 초대형 {xl}',
    'company.facilities': '시설',
    'company.customers': '고객',
    'company.perks': '퍽',
    'company.customerDetail': '고객 상세',
    'weather.noEffect': '영향 없음',
    'weather.title': '날씨',
    'weather.head': '이번 달 계절: {season} · 예보는 {n}턴 앞까지 (예보는 확정)',
    'weather.tent': '천막: 젖음 무효',
    'weather.note': '야외 적재 택배가 날씨의 영향을 가장 크게 받습니다. 폭염은 창고 안 🌾 농산물도 상하게 합니다(냉장 구역·환기 시설이면 무사).',
    'up.frozenOk': '❆ 냉동 구역 OK',
    'up.frozenNo': '❆ 냉동 자리 없음 → 즉시 폐기',
    'up.coldOk': '❄ 냉장 구역 OK',
    'up.coldNo': '❄ 냉장 자리 부족 → 상온',
    'up.customs': '🛃 통관 대기 {n}턴',
    'up.burst': '⚡ 폭주 입고 (기한 -2)',
    'up.title': '{n}턴 입고 예정',
    'up.volume': '부피 <b>{vol}</b>칸',
    'common.warehouse': '창고',
    'up.heat': '🌡 폭염 경보 턴: 냉장 밖 신선·냉동 즉시 폐기',
    'up.note': '입고 순서는 예정대로이며, 통관 대기·냉장 배정은 입고 시점 상태로 정해집니다.',
    'btn.close': '닫기',
    'common.none': '없음',
    'season.spring': '봄',
    'season.summer': '여름',
    'season.autumn': '가을',
    'season.winter': '겨울',
    'attr.cold': '냉장 구역 밖이면 다음 턴 폐기',
    'attr.fragile': '⚠ 능력 없는 업체로 보내면 파손 확률',
    'attr.customs': '통관 대기 중엔 처리 불가 (통관 대행 제외)',
    'attr.frozen': '냉동 구역 밖이면 즉시 폐기',
    'attr.produce': '폭염이면 창고 안이라도 상함 (냉장 구역·환기 시설이면 무사)',
    'pd.specialBonus': '특수 보너스 +{n}',
    'pd.breakRisk': '⚠ 파손 {pct}%',
    'pd.cannotCall': '호출 불가',
    'pd.baseReward': '기본 {n}c',
    'pd.perPiece': '(개당 +{n})',
    'pd.claim': '폐기 시 손해배상 <b style="color:var(--red)">{claim}c</b>',
    'pd.arrivedAgo': '입고 {n}턴 전',
    'pd.wet': '젖음 (보상 -20%)',
    'pd.outdoor': '🌧 야외 적재 중',
    'pd.contracts': '처리할 수 있는 계약',
    'pd.noContract': '계약 없음',
    'pd.selfRow': '직접 배송 (대기 턴)',
    'pd.selfCost': '배송비 {cost}c, 보상 그대로',
    'pd.ok': '가능',
    'offer.title': '{name} 보관 제안',
    'offer.prepaid': '선불 <b>{fee}c</b>',
    'offer.perTurn': '턴당 {perTurn}c 후불 ({total}c)',
    'offer.note': '수락 시 창고 {used} → {after}/{cap}{push} · 기간 중 손댈 수 없음, 무사히 끝나면 신뢰 +2',
    'offer.push': '(내 택배가 야외로 밀려남)',
    'offer.accept': '수락',
    'offer.decline': '거절',
    'offer.feeFloat': '보관료 +{n}c',
    'storage.postpaid': '회수 시 {n}c 후불',
    'storage.prepaid': '선불 {n}c 받음',
    'storage.earlyNote': '조기 반환: 남은 기간 환불 {refund}c + 위약금 30c = <b>{total}c</b> 지불, 고객 신뢰 -1. 급할 때 공간을 되찾는 탈출구입니다.',
    'storage.earlyBtn': '조기 반환 (-{n}c)',
    're.claim': '배상 {n}c',
    're.outOfZone': '구역 밖!',
    're.wet': '젖음',
    're.storageClaim': '도난 시 배상 ×2',
    're.inside': '창고 안',
    're.outside': '야외 <b>{vol}칸</b> · 도난 {pct}%',
    're.nextTurn': '다음 턴',
    're.presets': '프리셋',
    're.preUrgent': '급한 것 우선',
    're.preReward': '고보상 우선',
    're.preClaim': '고배상 우선',
    're.preCustomer': '{icon} 우선',
    're.zoneIn': '🏠 창고 안 — 탭하면 야외로',
    're.empty': '비어 있음',
    're.zoneOut': '🌧 야외 — 탭하면 창고 안으로',
    're.title': '적재 정리',
    'btn.apply': '적용',
    're.sub': '창고 안이 용량을 넘으면 덜 급한 것부터 자동으로 밀려납니다',
    'trust.next': '다음 {have}/{need}: {effect}',
    'trust.max': '최고 단계',
    'trust.remain': '{n}xp 남음',
    'ps.warm': '🔥 상온 · 다음 턴 폐기',
    'ps.cold': '❄ 냉장',
    'ps.frozenOut': '🔥 냉동 구역 밖',
    'ps.frozen': '❆ 냉동',
    'ps.heat': '🔥 폭염에 상함',
    'ps.customs': '🛃 통관 {n}턴{delayed}',
    'ps.delayed': '(지연)',
    'ps.overdue': '⏳ 초과{ret}',
    'ps.returnIn': '반송 {n}턴',
    'ps.deadline': '⏳ <b>{n}</b>턴',
    'hud.emptyWarehouse': '창고가 비어 있습니다',
    'call.riskTag': '⚠ 파손 위험',
    'call.spare': '예비 기사 (월 1회)',
    'call.xpGain': '이 호출 <b>+{xp}xp</b> ({parts})',
    'call.nextLevel': '다음 단계',
    'call.trackToggle': '단계별 해금',
    'call.capacity': '처리량 <b>{cap}</b>개',
    'call.remain': '잔여',
    'call.btn': '호출',
    'call.riskLine': '⚠ 파손 위험 {n}개 — 각 {pct}% (예상 손실 {loss}c). 파손되면 폐기 + 스트레스 +2',
    'call.caps': '능력',
    'call.size': '크기 {min}~{max}',
    'call.payLater': '⏱ 입금 {n}턴 뒤',
    'call.bonus': '보너스',
    'call.selected': '선택 <b>{n}</b>/{cap}개',
    'call.pickUrgent': '급한 순 자동 선택',
    'call.pickClear': '선택 해제',
    'call.instant': '⚡즉시 처리',
    'call.noTurn': '턴을 쓰지 않음',
    'call.maxSelect': '최대 {cap}개까지 선택할 수 있습니다',
    'float.broken': '⚠ 파손! {short}',
    'float.delayed': '+{n}c ({delay}턴 뒤)',
    'toast.custSuspend': '{name} 거래 중단 — 다음 달 재개',
    'float.claim': '손해배상 -{n}c',
    'toast.trustUp': '⭐ {name} 신뢰 {level}단계: {effect}',
    'float.self': '직접 배송 +{rev}c (배송비 -{cost}c)',
    'pd.sizeOut': '크기 범위 밖',
    'pd.plainOnly': '속성 없는 택배만',
    'pd.notSpecial': '전문 대상 아님',
    'pd.noFrozenCap': '❆ 능력 없음',
    'pd.no': '불가',
    'wm.rewardCost': '보상 <b>{reward}</b>c · 배송비 <b style="color:var(--orange)">{cost}</b>c',
    'wm.overdue': '⏳ 기한 초과 {n}개',
    'wm.spoil': '🥀 부패 {n}개',
    'wm.frozenOver': '❆ 냉동 자리 없음 {n}개',
    'wm.nextWarehouse': '다음 턴 창고',
    'wm.ifWait': '대기하면',
    'wm.outdoor': '🌧 야외 {vol}칸 · 이번 턴 도난 {pct}%',
    'wm.selfHead': '🚚 직접 배송 — 이 턴에 <b>{n}개</b>까지 (크기 ≤ {size}) · 보상은 그대로, 배송비 {base}c + 크기×{per}c',
    'wm.vans': '차량',
    'wm.noVans': '차량 없음 — 속성 없는 택배·농산물만',
    'wm.blocked': '직접 배송 불가 {n}개 (택배 상세에서 사유 확인)',
    'wm.title': '대기',
    'wm.selfWait': '직접 배송 {n}개 후 대기 (-{cost}c)',
    'wm.justWait': '그냥 대기',
    'wm.sub': '호출 없이 턴을 넘깁니다',
    'wm.limit': '한 턴에 {n}개까지',
    'float.discard': '폐기! {why}',
    'float.paid': '{name} 입금 +{n}c',
    'float.storageEnd': '보관 회수 {pay}',
    'float.storageStolen': '보관 물품 도난! -{n}c',
    'toast.offer': '보관 제안이 왔습니다',
    'float.returned': '반송! {short}',
    'float.stolen': '도난! {short}{size}',
    'float.stress': '스트레스 +{n}',
    'sum.revenue': '배송 수익',
    'sum.opCost': '월말 운영비',
    'sum.closing': '월말 결산 보너스',
    'sum.callsWaits': '업체 호출 / 대기',
    'sum.delivered': '처리한 택배',
    'sum.penalty': '이번 달 페널티',
    'sum.rsb': '반송 / 도난 / 파손',
    'sum.claims': '손해배상',
    'sum.covered': '(보험 {n} 보장)',
    'sum.premium': '보험료 ({name})',
    'sum.claimsNext': '청구 {n}건 → 다음 달 보험료 {next}c',
    'sum.noClaimBonus': '무사고 2개월: 고객 전원 신뢰 +1',
    'sum.selfCost': '직접 배송비',
    'sum.storageIncome': '보관료',
    'sum.overdueVol': '기한 초과 보관 중',
    'sum.discarded': '부패 폐기',
    'sum.runDiscard': '(런 누적 {n}/{max})',
    'sum.cash': '현재 자금',
    'sum.goal': '(목표 {n})',
    'sum.stress': '스트레스',
    'sum.usage': '창고 사용률',
    'sum.usageVal': '{pct}% ({n}개 보관 중)',
    'sum.deliverGoal': '처리 목표',
    'sum.storageGoal': '보관 계약 완수',
    'fmt.cases': '{n}건',
    'sum.bigCustomer': '대형 계약 고객',
    'common.trust': '신뢰',
    'sum.custClaim': '배상 -{n}c',
    'sum.title': '{n}개월차 정산',
    'sum.final': '최종 결과',
    'sum.toMarket': '마켓으로',
    'mk.capCalls': '회당 {cap}개 · 최대 {calls}회',
    'mk.oneTime': '(1회성)',
    'mk.claimMult': '배상 ×{n}',
    'mk.custStart': '신뢰 0단계로 거래 시작 (고객 {n}/{max})',
    'common.xl': '초대형',
    'mk.afterBuy': '구매 후',
    'mk.allFacilities': '이미 모든 시설을 구매했습니다',
    'mk.sold': '판매됨',
    'mk.currentContracts': '현재 계약 (교체 시 잔여 호출·강화 소멸{keep}. 업체 신뢰도는 유지)',
    'mk.keepCalls': ', 잔여 {n}회 보존',
    'mk.contractLine': '잔여 {calls}/{max}회, 회당 {cap}개',
    'mk.mine': '내 계약',
    'mk.prepNote': '1개월차 시작 전입니다.',
    'mk.bought': '구매',
    'mk.refresh': '마켓 새로고침 ({cost})',
    'mk.free': '무료',
    'mk.prepTitle': '준비 마켓',
    'mk.title': '{n}개월차 마켓',
    'mk.startMonth': '{n}개월차 시작',
    'toast.strike': '✊ 이번 달 {name} 파업 — 호출 불가',
    'mk.priceMult': '가격 ×{n}',
    'slot.pickReplace': '교체할 슬롯을 고르세요. 잔여 호출·강화는 사라지고 업체 신뢰도는 남습니다.',
    'slot.pickApply': '적용할 계약을 고르세요.',
    'slot.emptyHint': '여기에 새 계약을 넣습니다',
    'slot.limitEnh': '한도강화 {n}/2',
    'slot.capEnh': '용량강화 {n}/3',
    'kind.contract': '계약',
    'kind.enh': '강화',
    'kind.fac': '시설',
    'kind.item': '보험',
    'kind.customer': '고객',
    'res.unlocked': '🔓 {name} 해금',
    'res.best': '★ 최고 기록',
    'res.scenarioCompany': '시나리오 / 회사',
    'res.reached': '도달',
    'res.revenue': '총 배송 수익',
    'res.spent': '총 지출',
    'res.cash': '최종 자금',
    'res.callsWaits': '호출 / 대기',
    'res.deliveredDiscarded': '처리 택배 / 폐기',
    'res.seed': '시드',
    'res.toTitle': '타이틀로',
    'res.again': '같은 조건으로 다시',
    'res.win': '런 성공!',
    'res.over': '게임오버',
    'rec.head': '최고 기록 <b>{best}점</b> · 런 {runs}회 (성공 {clears})',
    'rec.dailyStreak': '데일리 연속 {n}일',
    'rec.win': '성공',
    'rec.lose': '실패',
    'rec.empty': '아직 기록이 없습니다.',
    'rec.title': '런 기록',
    'cust.next': '다음 {have}/{need}',
    'cust.lv1': '물량 ×1.0 · 개당 +5 (0단계는 물량 ×0.6)',
    'cust.defaultMix': '월별 기본 비율',
    'cust.thisMonth': '이번 달 {n}개 · +{rev}c',
    'cust.suspendedLong': '거래 중단 (다음 달 재개)',
    'ins.current': '가입 중',
    'ins.nextMonth': '다음 달 {n}c',
    'ins.joinFee': '가입비 {n}c · 월 {n}c',
    'ins.fans': '선호 고객',
    'ins.noFans': '(이 회사에 없음)',
    'ins.startup': '스타트업은 첫 달 무보험. 2개월차 마켓부터 가입할 수 있습니다',
    'ins.rules': '보험료는 월말에 차감. 청구 0건이면 다음 달 ×0.8(연속 2개월 ×0.7 + 고객 전원 신뢰 +1), 3~4건 ×1.3, 5건↑ ×1.7·보장 절반. 갈아타면 새 보험사 기본 보험료를 가입비로 냅니다.',
    'ins.coverHalf': '이번 달 보장 절반 (지난달 청구 5건 이상)',
    'ins.marketOnly': '보험은 마켓에서 갈아탈 수 있습니다',
    'ins.confirm': '{name}(으)로 바꿀까요? 가입비 {fee}c',
    'ins.join': '가입',
    'cust.rules': '기한 내 처리 +1xp · 특수 규칙 +1xp · 폐기 -3xp (0 밑이면 거래 중단). 신뢰가 오르면 물량과 개당 보상이 오르고, 폐기하면 고객이 손해배상을 청구합니다.',
    'my.slot': '슬롯 {n}',
    'my.limit': '호출 한도 +{n}',
    'my.cap': '처리 용량 +{n}',
    'my.remain': '잔여 {calls}/{max}회',
    'my.stats': '회당 <b>{cap}</b>개 · 이번 런 {calls}회 호출 · {n}개 처리',
    'my.others': '계약은 없지만 신뢰도가 남아 있는 업체',
    'my.note': '교체 시 잔여 호출·강화 소멸{keep}. 업체 신뢰도는 유지',
    'codex.carriersHead': '운송 업체 · 신뢰도는 업체에 쌓이고 계약을 바꿔도 유지',
    'codex.liveRun': '(현재 런 진행도)',
    'codex.carrierPrice': '회당 {cap} · {calls}회 · {price}c',
    'codex.need': '전용({icons})',
    'codex.perkSlots': '퍽 슬롯 {n}개 · 같은 계열은 하나만 장착',
    'codex.slotReward': '퍽 슬롯 {n}개',
    'codex.multiReward': '반기 결산 + 퍽 슬롯 2개',
    'stat.runsClears': '런 / 클리어',
    'stat.best': '최고 점수',
    'stat.delivered': '처리 택배',
    'stat.contracts': '계약 구매',
    'stat.tidy': '깔끔한 월말',
    'stat.daily': '데일리 연속',
    'fmt.days': '{n}일',
    'stat.profileNote': '프로필은 이 기기에 저장됩니다 (구글 플레이 게임즈 연동 예정).',
    'stat.reset': '프로필 초기화',
    'stat.resetConfirm': '해금·도전과제·기록을 모두 지웁니다. 계속할까요?',
    'stat.resetBtn': '초기화',
    'log.title': '진행 기록',
    'menu.title': '메뉴',
    'menu.autosave': '진행 상황은 매 턴 자동 저장됩니다.',
    'menu.volume': '음악 볼륨',
    'menu.continue': '계속하기',
    'menu.abandon': '런 포기',
    'menu.abandonConfirm': '이 런을 포기하고 타이틀로 돌아갈까요? (기록에는 남지 않습니다)',
    'menu.abandonBtn': '포기',
    'opt.turnOn': '켜기',
    'opt.turnOff': '끄기',
    'btn.help': '도움말',
    'fmt.wins': '{n}승',
    'codex.tab.companies': '회사',
    'codex.tab.carriers': '업체',
    'codex.tab.perks': '퍽',
    'codex.tab.scenarios': '시나리오',
    'codex.tab.achievements': '도전과제',
    'codex.tab.stats': '통계',
    'codex.ach.company': '회사 해금',
    'codex.ach.scenario': '시나리오 해금',
    'codex.ach.slot': '퍽 슬롯',
    'codex.ach.multi': '첫 클리어',
    'codex.ach.perk': '퍽 해금',
    'codex.ach.none': '기록',
    'help.body': '<div class="help">\n      <p>택배가 매 턴 창고로 들어옵니다. 운송 업체를 호출해 처리하거나 <b>대기</b>해서 택배를 모아 두세요. 호출 비용은 택배 개수가 아니라 <b>호출 횟수</b> 기준이므로, 한 번에 많이 처리할수록 이득입니다.</p>\n      <h3>런 준비</h3><p><b>시나리오</b>(길이·규칙) → <b>회사</b>(시작 창고·계약·고유 특성) → <b>퍽</b>(작은 규칙 변경) 순서로 고릅니다. 회사·퍽·시나리오는 <b>도전과제</b>로 해금되며, 도감에서 조건과 진행도를 볼 수 있습니다. 회사는 <b>1단계</b>(런 3회·첫 클리어·2회 클리어) → <b>2단계</b>(택배 종류별 누적 30개) → <b>3단계</b>(회사 3개로 클리어) 순으로 열립니다.</p>\n      <h3>한 턴의 순서</h3><p>입고 → 업체 호출 또는 대기 → 배송 → 신선도·기한 진행 → 창고 초과·지연 페널티</p>\n      <h3>택배 속성 — 창고에서 벌어지는 일</h3><table><tr><th>속성</th><th>규칙</th><th>보낼 수 있는 업체</th></tr>\n      <tr><td>❄ 신선</td><td>냉장 구역 밖이면 <b>다음 턴 폐기</b>. 기한 3턴</td><td>아무 업체 (보너스는 냉장 물류만)</td></tr>\n      <tr><td>⚠ 파손</td><td>⚠ 능력 없는 업체로 보내면 <b>25% 파손</b>(폐기 +2)</td><td>아무 업체. 안전: 프래자일·대형·철도·항공·긴급·완충 특약</td></tr>\n      <tr><td>🛃 통관</td><td>입고 후 <b>2턴 통관 대기</b>(20% 지연 +1). 대기 중엔 자리만 차지, 기한은 그 뒤 시작</td><td>대기 후 아무 업체. 대기 중엔 통관 대행·항공·해상·긴급만</td></tr>\n      <tr><td>❆ 냉동</td><td>냉동 구역 밖이면 <b>즉시 폐기</b>. 기한 8턴. 4개월차부터. 냉동 구역보다 큰 택배는 오지 않음</td><td>냉동 물류·냉동 컨테이너 특약만</td></tr>\n      <tr><td>🌾 농산물</td><td>창고 안에 있어도 <b>폭염이면 기한 -2</b>(야외면 폐기). 남는 냉장 자리에 들어가거나 환기 시설이 있으면 무사. 기한 5턴</td><td>아무 업체 (보너스는 냉장 물류). 자체 배송 가능</td></tr>\n      <tr><td>대형(4~7)</td><td>크기 범위가 맞는 업체만</td><td>용달·대형 화물·철도·해상·통관 대행</td></tr></table>\n      <h3>대기 · 직접 배송 · 차량</h3><p><b>대기</b>를 누르면 턴 넘기기 화면이 열립니다. 여기서 택배를 골라 <b>직접 배송</b>할 수 있습니다 — 한 턴에 1개(대형 트럭 +1, 도심 퀵·국영 +1), 속성 없는 택배·농산물, 크기 2까지. 보상은 그대로 받고 대신 <b>배송비</b>(15c + 크기×5c)를 냅니다. 마켓의 <b>차량</b>으로 넓힙니다: 냉동 탑차(❄❆), 완충 포장차(⚠ 안전), 대형 트럭(크기 4, +1개). 야외 적재가 있으면 같은 화면에서 적재 정리로 들어갑니다. 택배 행을 탭하면 어떤 계약·직접 배송으로 처리할 수 있는지 보입니다.</p>\n      <h3>준비 마켓</h3><p>런은 <b>준비 마켓</b>으로 시작합니다. 1개월차 첫 턴 전에 시작 자금으로 계약·강화·시설·보험을 갖출 수 있고, 1~2턴 입고 예정과 날씨가 보입니다. 새로고침 1회 무료. 한 달짜리 시나리오도 여기서 대비합니다.</p>\n      <h3>난이도</h3><p>시나리오 화면 위에서 <b>수습·정규·베테랑</b>을 고릅니다. 수습은 입고·가격·배상이 줄고 예정이 3턴까지 보이지만 해금 도전과제가 인정되지 않습니다. 베테랑(첫 클리어 후)은 입고 +10%, 배상 ×1.5, 도난·파손 ×1.3, 스트레스 한계 18, 점수 ×1.4.</p>\n      <h3>날씨 · 적재 · 보관 · 보험</h3><p>턴마다 날씨가 있고 2턴 앞까지 예보됩니다. <b>🌧 비</b>는 야외 일반·⚠ 택배를 적셔 보상 -20%, <b>🔥 폭염</b>은 냉장 밖 ❄❆ 즉시 폐기, <b>❄️ 폭설</b>은 야외가 냉장고가 되고(❄ 부패 없음, 도난 절반, ❄ 처리 +10), <b>🌀 태풍</b>은 도난 2배에 그 턴 입고가 다음 턴으로 몰립니다.</p><p>창고가 넘칠 때 <b>대기</b>를 누르면 <b>적재 정리</b>가 열립니다. 무엇을 야외에 둘지 직접 고르거나 프리셋(급한 것·고보상·고배상·고객 우선)을 씁니다. 호출 턴에는 열리지 않습니다 — 대기의 보상입니다.</p><p>이사센터 같은 고객이 <b>보관 계약</b>을 제안합니다. 수락하면 선불 보관료를 받고 그 부피가 기간 동안 창고를 차지합니다(호출·정리 대상 아님). 무사히 끝나면 신뢰 +2, 조기 반환은 남은 기간 환불 + 위약금 30c. 야외로 내보내 도난당하면 배상 ×2.</p><p><b>보험</b>은 런 시작 때 고르고 마켓에서 갈아탈 수 있습니다. 배상액의 일부를 보험이 대신 내고, 월 보험료는 정산에서 빠집니다. 청구 0건이면 다음 달 -20%(연속 2개월 -30% + 고객 신뢰 +1), 많으면 인상. 무보험이면 배상 ×2 고객(유리공방·이사센터)의 물량이 절반. 마켓의 1회성 보험(운송 보험증·야적 보험·통관 보증)도 있습니다.</p>\n      <h3>고객</h3><p>택배마다 보낸 <b>고객</b>이 있습니다(행 왼쪽 아이콘). 기한 내 처리 +1xp, 고객 특수 규칙 충족 +1xp, 폐기 -3xp. 신뢰 1~3단계에서 물량과 개당 보상이 오르고 2·3단계에 고객 혜택이 열립니다. 폐기(부패·반송·도난·파손)가 나면 고객이 <b>손해배상</b>(기본 보상 × 배상 배율)을 청구해 자금에서 바로 빠지고, xp가 0 밑으로 떨어지면 다음 달까지 거래가 끊깁니다. 하단 <b>고객</b> 버튼에서 확인하세요.</p>\n      <p>업체 카드의 <b>능력</b> 아이콘이 그 업체가 안전하게 다루는 속성입니다. 강화 슬롯의 <b>특약</b>으로 계약에 속성 하나를 붙일 수 있습니다(계약당 1개). ✈🚆🚢는 운송 수단 표시일 뿐 매칭과 무관하고, 철도·해상은 보상이 1~2턴 뒤에 입금됩니다.</p>\n      <h3>세 가지 배송 수단</h3><p><b>직접 배송</b>: 대기 턴에 택배 1개를 골라 배송비를 내고 처리(보상 그대로). <b>업체 호출</b>: 계약의 잔여 호출을 1회 쓰고 턴 소모. 전문 업체는 보너스. <b>⚡긴급 특송</b>: 턴을 쓰지 않고 즉시 1개 처리 — 대기 전략의 안전장치.</p>\n      <p>용달은 어떤 택배든 1개(보너스 없음, ⚠ 파손 위험). 기한을 넘기면 보상 -25%와 스트레스 +1, 3턴 더 지나면 <b>반송</b>(스트레스 +2)됩니다. 창고를 넘긴 만큼 최근 입고분이 <b>야외 적재</b>되어 매 턴 도난 판정(초과 1~2: 15%, 3~5: 30%, 6+: 50%)을 받습니다. 신선식품은 3턴이 지나면 보상 50%, 그 다음 턴에 폐기(+3). 상온(❄ 아님)의 신선식품은 2배 빨리 상합니다.</p>\n      <h3>창고</h3><p>용량 초과 1~2: +1, 3 이상: +2 스트레스 — 진짜 위험은 야외 적재분의 도난입니다. 스트레스 {stress}이면 게임오버. 월말에는 운영비가 정산됩니다.</p>\n      <h3>계약과 마켓</h3><p>계약마다 잔여 호출 횟수가 있고 월중에는 새 계약을 살 수 없습니다. 월말 마켓에서 계약 교체·강화·시설을 구매하세요. 계약을 교체하면 잔여 호출·신뢰도·강화가 사라집니다. 등급: 일반 &lt; 신뢰 &lt; 전문 &lt; 마스터.</p>\n      <h3>업체 신뢰도</h3><p>신뢰도는 <b>업체</b>에 쌓이고 계약을 바꿔도 유지됩니다. 호출 1회마다: 정상 처리 +1, 처리량 80% 이상 +1, 전문 업체로 특수 택배 +1. 호출 화면에서 이번 호출의 예상 xp를 보여줍니다.</p>\n      <table><tr><th>단계</th><th>필요 xp</th><th>효과</th></tr><tr><td>1</td><td>3</td><td>회당 처리량 +1</td></tr><tr><td>2</td><td>8</td><td>4번째 호출마다 +1개</td></tr><tr><td>3</td><td>15</td><td>전용 능력 (냉장: 기한 정지 / 대량·통관·대형·냉동·긴급: +1개 / 용달: 특수 보너스 / 프래자일: +15c / 항공: 크기 4 / 철도·해상: 입금 지연 -1)</td></tr></table>\n      <p>가장 빠른 길: 같은 업체를 <b>가득 채워서</b>(80%↑) 부르면 매번 +2~3xp라 5~6회 호출로 3단계에 닿습니다.</p></div>',
  },
  data:   {
    "ATTRS": {
      "cold": {
        "name": "냉장"
      },
      "fragile": {
        "name": "파손"
      },
      "customs": {
        "name": "통관"
      },
      "frozen": {
        "name": "냉동"
      },
      "produce": {
        "name": "농산물"
      }
    },
    "PARCEL_TYPES": {
      "normal": {
        "name": "일반",
        "short": "일반"
      },
      "fresh": {
        "name": "신선식품",
        "short": "신선"
      },
      "produce": {
        "name": "농산물",
        "short": "농산"
      },
      "fragile": {
        "name": "파손주의",
        "short": "파손"
      },
      "intl": {
        "name": "통관 화물",
        "short": "통관"
      },
      "large": {
        "name": "대형화물",
        "short": "대형"
      },
      "frozen": {
        "name": "냉동식품",
        "short": "냉동"
      }
    },
    "CARRIERS": {
      "target": {
        "name": "용달",
        "short": "용달",
        "desc": "원하는 택배 1개를 골라 차를 불러 보냄 (특수 보너스 없음, ⚠ 파손 위험)"
      },
      "cold": {
        "name": "냉장 물류",
        "short": "냉장",
        "desc": "신선·농산물 전문. 신선·농산물 보너스"
      },
      "bulk": {
        "name": "대량 분류",
        "short": "대량",
        "desc": "일반 택배를 골라 한 번에 처리"
      },
      "fragile": {
        "name": "프래자일 전문",
        "short": "프래",
        "desc": "파손주의 전문. 파손 없음, 파손 보너스"
      },
      "intl": {
        "name": "통관 대행",
        "short": "통관",
        "desc": "통관 대기 중인 화물을 즉시 통관·발송. 통관 보너스"
      },
      "large": {
        "name": "대형 화물",
        "short": "대형",
        "desc": "크기 4 이상 택배를 처리 (파손 안전). 대형 보너스"
      },
      "frozen": {
        "name": "냉동 물류",
        "short": "냉동",
        "desc": "냉동 전용. 냉동 보너스"
      },
      "urgent": {
        "name": "긴급 특송",
        "short": "긴급",
        "desc": "⚡턴을 쓰지 않고 즉시 1개 처리. 통관 대기 중·파손도 안전, 보너스 없음"
      },
      "air": {
        "name": "항공 특송",
        "short": "항공",
        "desc": "소형(1~2)만. 통관 대기 중 처리·파손 안전. 비싸지만 빠름"
      },
      "rail": {
        "name": "철도 수송",
        "short": "철도",
        "desc": "파손 안전, 한 번에 많이. 보상은 다음 턴 입금"
      },
      "sea": {
        "name": "해상 운송",
        "short": "해상",
        "desc": "통관 컨테이너, 크기 2 이상, 파손 안전. 보상은 2턴 뒤 입금"
      }
    },
    "CARRIER_L3": {
      "target": "특수 택배 처리 시 특수 운송 보너스 적용",
      "cold": "호출 턴에 신선·농산물 기한 정지",
      "bulk": "일반 택배 1개 추가 처리",
      "fragile": "파손주의 처리 시 보상 +15",
      "intl": "통관 화물 1개 추가 처리",
      "large": "초대형 화물 2개를 한 번에 처리 (처리량 +1)",
      "frozen": "냉동 1개 추가 처리",
      "urgent": "한 번에 2개 처리",
      "air": "크기 4까지 처리",
      "rail": "입금 지연 없음",
      "sea": "입금 지연 1턴"
    },
    "SELF_DELIVERY": {
      "name": "직접 배송"
    },
    "GRADES": {
      "normal": {
        "name": "일반"
      },
      "trusted": {
        "name": "신뢰"
      },
      "expert": {
        "name": "전문"
      },
      "master": {
        "name": "마스터"
      }
    },
    "TRUST_EFFECTS": [
      "기본",
      "회당 처리량 +1",
      "4번째 호출마다 +1개",
      "전용 능력"
    ],
    "ENHANCEMENTS": {
      "limit1": {
        "name": "호출 한도 +1",
        "desc": "계약 최대/잔여 호출 횟수 +1 (계약당 2회)"
      },
      "limit2": {
        "name": "호출 한도 +2",
        "desc": "계약 최대/잔여 호출 횟수 +2 (계약당 2회)"
      },
      "cap1": {
        "name": "처리 용량 강화 I",
        "desc": "회당 처리량 +1 (계약당 3회)"
      },
      "regular": {
        "name": "정기 배차",
        "desc": "해당 계약의 4번째 성공 호출마다 추가 1개 처리"
      },
      "express": {
        "name": "고속 배차",
        "desc": "해당 계약의 3번째 성공 호출마다 추가 1개 처리"
      },
      "seal": {
        "name": "신뢰도 인장",
        "desc": "선택한 계약의 신뢰도 경험치 +3"
      },
      "record": {
        "name": "장기 거래 기록",
        "desc": "선택한 계약의 신뢰도 경험치 +6"
      },
      "optFragile": {
        "name": "완충 포장 특약",
        "desc": "이 계약이 ⚠ 파손을 안전하게 처리 (계약당 특약 1개)"
      },
      "optCold": {
        "name": "보냉 특약",
        "desc": "이 계약이 ❄ 신선을 처리(보너스 없음), 회당 처리량 -1"
      },
      "optCustoms": {
        "name": "통관 대행 특약",
        "desc": "이 계약이 🛃 통관 대기 중 화물을 처리, 계약 최대 호출 -1"
      },
      "optFrozen": {
        "name": "냉동 컨테이너 특약",
        "desc": "이 계약이 ❆ 냉동을 처리, 회당 -1 (크기 최대 4 이하 계약만)"
      }
    },
    "FACILITIES": {
      "expand1": {
        "name": "창고 확장 1단계",
        "desc": "전체 용량 +8"
      },
      "expand2": {
        "name": "창고 확장 2단계",
        "desc": "전체 용량 +10"
      },
      "expand3": {
        "name": "창고 확장 3단계",
        "desc": "전체 용량 +12"
      },
      "cold1": {
        "name": "냉장고 증설",
        "desc": "냉장 용량 +4"
      },
      "cold2": {
        "name": "냉장고 증설 2",
        "desc": "냉장 용량 +6"
      },
      "yard": {
        "name": "대형 적재장",
        "desc": "초대형 보관 +1"
      },
      "freezer1": {
        "name": "냉동고 증설",
        "desc": "냉동 용량 +4"
      },
      "vent": {
        "name": "환기 시설",
        "desc": "창고 안 🌾 농산물이 폭염에 상하지 않음"
      },
      "coldvan": {
        "name": "냉동 탑차",
        "desc": "직접 배송으로 ❄ 신선·❆ 냉동 처리"
      },
      "padvan": {
        "name": "완충 포장차",
        "desc": "직접 배송으로 ⚠ 파손을 안전하게 처리"
      },
      "bigvan": {
        "name": "대형 트럭",
        "desc": "직접 배송 +1개, 크기 4까지"
      }
    },
    "STRESS_NAMES": {
      "stable": "안정",
      "caution": "주의",
      "danger": "위험",
      "crisis": "위기",
      "gameover": "게임오버"
    }
  },
  meta:   {
    "CUSTOMERS": {
      "anon": {
        "name": "개인 고객",
        "desc": "동네 개인 택배. 월별 기본 비율"
      },
      "dawn": {
        "name": "새벽마켓",
        "rule": {
          "text": "새벽배송: 입고 당 턴에 처리하면 +20"
        },
        "perks": {
          "2": {
            "text": "냉장 구역 +2 대여"
          },
          "3": {
            "text": "이 고객 신선 기한 +1"
          }
        }
      },
      "mart": {
        "name": "큰마트",
        "rule": {
          "text": "정기 배송: 한 호출에 큰마트 택배 3개 이상이면 +10%"
        },
        "perks": {
          "2": {
            "text": "대량 분류 회당 +1"
          },
          "3": {
            "text": "이 고객 택배 보상 +5"
          }
        }
      },
      "glass": {
        "name": "유리공방",
        "rule": {
          "text": "취급 주의: 파손 없이 5개 연속 처리하면 +30"
        },
        "perks": {
          "2": {
            "text": "이 고객 택배 파손 확률 절반"
          },
          "3": {
            "text": "이 고객 파손 보너스 +10"
          }
        }
      },
      "import": {
        "name": "직구몰",
        "rule": {
          "text": "통관 예고: 이 고객 통관 대기 -1턴"
        },
        "perks": {
          "2": {
            "text": "통관 대행 마켓 등장 ×2"
          },
          "3": {
            "text": "이 고객 통관 보너스 +15"
          }
        }
      },
      "factory": {
        "name": "가구공장",
        "rule": {
          "text": "묶음 출고: 같은 턴 입고분을 한 호출로 처리하면 +25"
        },
        "perks": {
          "2": {
            "text": "초대형 보관 +1"
          },
          "3": {
            "text": "이 고객 대형 점유 -1"
          }
        }
      },
      "ice": {
        "name": "아이스팩토리",
        "rule": {
          "text": "콜드체인: 냉동 택배 처리 시 +15"
        },
        "perks": {
          "2": {
            "text": "냉동고 증설 -50%"
          },
          "3": {
            "text": "이 고객 냉동 기한 +2"
          }
        }
      },
      "luxury": {
        "name": "명품관",
        "rule": {
          "text": "보안 운송: 통관 대기 중 야외에 두지 않으면 +20"
        },
        "perks": {
          "2": {
            "text": "항공 특송 마켓 등장 ×2"
          },
          "3": {
            "text": "이 고객 통관 대기 -1"
          }
        }
      },
      "farm": {
        "name": "농협 직송",
        "rule": {
          "text": "수확기: 입고 2턴 안에 처리하면 +15"
        },
        "perks": {
          "2": {
            "text": "환기 시설 -50%"
          },
          "3": {
            "text": "이 고객 농산물 기한 +1"
          }
        }
      },
      "mover": {
        "name": "이사센터",
        "desc": "보관 계약만 제안한다",
        "perks": {
          "2": {
            "text": "보관료 +20%"
          },
          "3": {
            "text": "이삿짐 점유 -2"
          }
        }
      }
    },
    "STORAGE_KINDS": {
      "move": {
        "name": "이삿짐"
      },
      "season": {
        "name": "계절 재고"
      },
      "event": {
        "name": "행사 물품"
      }
    },
    "INSURERS": {
      "none": {
        "name": "무보험",
        "desc": "보장 없음. 배상 배율 ×2 고객은 물량 절반"
      },
      "sturdy": {
        "name": "든든화재",
        "desc": "모든 폐기 배상 50%"
      },
      "coldguard": {
        "name": "콜드가드",
        "desc": "❄❆ 부패 배상 80%, 그 외 20%"
      },
      "safebox": {
        "name": "세이프박스",
        "desc": "⚠ 파손·도난 배상 80%, 그 외 20%"
      },
      "premier": {
        "name": "프리미어",
        "desc": "모든 배상 90% + 반송 스트레스 면제"
      }
    },
    "INS_ITEMS": {
      "transitCert": {
        "name": "운송 보험증",
        "desc": "다음 호출 1회의 파손 확률 0"
      },
      "yardIns": {
        "name": "야적 보험",
        "desc": "다음 달 도난 배상 100%"
      },
      "customsBond": {
        "name": "통관 보증",
        "desc": "다음 달 통관 지연 무효"
      }
    },
    "WEATHER": {
      "sunny": {
        "name": "맑음",
        "desc": ""
      },
      "rain": {
        "name": "비",
        "desc": "야외 일반·⚠ 택배 젖음 (보상 -20%)"
      },
      "heat": {
        "name": "폭염",
        "desc": "냉장 밖 ❄❆ 즉시 폐기"
      },
      "snow": {
        "name": "폭설",
        "desc": "야외 ❄ 부패 없음·❆ 1턴 유예, 도난 절반, ❄ 기한 정지, ❄ 처리 +10"
      },
      "storm": {
        "name": "태풍",
        "desc": "도난 2배, 젖음, 이 턴 입고 없음(다음 턴에 몰림)"
      }
    },
    "DIFFICULTIES": {
      "rookie": {
        "name": "수습",
        "desc": "입고 ×0.85, 운영비 -20, 가격 ×0.9, 도난·파손·배상 ×0.5, 예정 3턴, 스트레스 한계 24. 점수 ×0.7. 해금 도전과제 인정 안 됨"
      },
      "normal": {
        "name": "정규",
        "desc": "기본 규칙"
      },
      "veteran": {
        "name": "베테랑",
        "desc": "입고 ×1.1, 운영비 +30, 가격 ×1.1, 도난·파손 ×1.3, 배상 ×1.5, 속성 2개 택배 +3%p, 스트레스 한계 18. 점수 ×1.4"
      }
    },
    "COMPANIES": {
      "local": {
        "name": "동네 택배",
        "tag": "균형형 · 기준선",
        "passive": "동네 단골: 매월 첫 호출의 처리량 +1",
        "weakness": "없음"
      },
      "fresh": {
        "name": "프레시 로지스틱스",
        "tag": "신선식품 특화",
        "passive": "콜드체인: 신선식품 기한 +1턴. 냉장 물류 호출 시 신뢰도 +1 추가",
        "weakness": "냉장 편중: 파손·통관 보상 -10%. 대형 화물 업체 마켓 미등장"
      },
      "steel": {
        "name": "강철 창고",
        "tag": "대형화물 · 공간",
        "passive": "적재 전문: 크기 4 이상 택배의 점유량 -1. 대형 화물 회당 처리량 +1",
        "weakness": "냉장 없음: 신선식품은 항상 상온(부패 2배). 냉장 용량 최대 4"
      },
      "quick": {
        "name": "도심 퀵",
        "tag": "좁은 창고 · 잦은 호출",
        "passive": "빠른 배차: 모든 계약의 최대·잔여 호출 +2. 직접 배송 +1개",
        "weakness": "협소: 창고 확장 효과 절반. 초대형은 항상 임시 공간 +3"
      },
      "global": {
        "name": "글로벌 익스프레스",
        "tag": "통관 화물 · 고보상",
        "passive": "관세 환급: 통관 화물 보상 +20. 통관 대행은 신뢰 3단계로 시작",
        "weakness": "환율 변동: 월말 운영비 100~160 무작위. 일반 보상 -5"
      },
      "glass": {
        "name": "유리방 물류",
        "tag": "파손주의 · 정밀",
        "passive": "완충 포장: 파손주의 처리 기한 +2턴, 보상 +15",
        "weakness": "조심조심: 대량 분류 처리량 -1. 한 호출 5개 이상이면 그 호출 보상 -10%"
      },
      "thrifty": {
        "name": "짠돌이 운송",
        "tag": "절약형의 극단",
        "passive": "알뜰 계약: 모든 마켓 가격 -20%. 대기한 턴마다 다음 호출 처리량 +1 (최대 +3)",
        "weakness": "인력 부족: 모든 계약 최대 호출 -1. 월말 운영비 +40"
      },
      "startup": {
        "name": "스타트업 딜리버리",
        "tag": "무작위 · 고위험",
        "passive": "피벗: 매월 마켓 새로고침 1회 무료. 마켓 계약 슬롯 3개. 신뢰 이상 등급 확률 +15%p",
        "weakness": "불안정: 월말마다 시작 계약 하나의 잔여 호출 -1. 3개월차부터 운영비 +30"
      },
      "postal": {
        "name": "국영 우편",
        "tag": "안정형 · 장기전",
        "passive": "공공 서비스: 운영비 80 고정. 직접 배송 +1개. 스트레스 10 이상이면 월초 -2. 계약 교체 시 잔여 호출 1회 보존",
        "weakness": "느린 결재: 마켓 매월 2개까지. 전문·마스터는 5개월차부터. 특수 보너스 -5"
      }
    },
    "PERKS": {
      "longdeal": {
        "name": "장기 거래",
        "desc": "모든 계약 비용 -10%"
      },
      "prepay": {
        "name": "선불 할인",
        "desc": "매월 첫 계약 구매 -40"
      },
      "protect": {
        "name": "재계약 보호",
        "desc": "계약 교체 시 잔여 호출 1회 보존"
      },
      "regularco": {
        "name": "단골 업체",
        "desc": "모든 업체 신뢰도 3xp(1단계)로 시작"
      },
      "spare": {
        "name": "예비 기사",
        "desc": "매월 1회, 잔여 호출 0인 계약을 한 번 더 호출"
      },
      "bundle": {
        "name": "묶음 할인",
        "desc": "한 호출로 4개 이상 처리하면 호출 횟수 미소모 (월 1회)"
      },
      "compact": {
        "name": "공간 최적화",
        "desc": "모든 택배 크기 -1 (최소 1)"
      },
      "coldpro": {
        "name": "냉장 전문가",
        "desc": "신선식품 유통기한 +1턴"
      },
      "tempyard": {
        "name": "임시 적재장",
        "desc": "창고 초과 1~2는 페널티 없음"
      },
      "shelves": {
        "name": "선반 증설",
        "desc": "시작 용량 +4"
      },
      "freezer": {
        "name": "냉동고",
        "desc": "냉장 구역의 신선식품은 첫 2턴 동안 부패 정지"
      },
      "yard": {
        "name": "야적장",
        "desc": "초대형 보관 +1, 초대형 임시 공간 3→2"
      },
      "skip": {
        "name": "스킵 보너스",
        "desc": "대기 후 다음 호출의 처리량 +1"
      },
      "insure": {
        "name": "폐기 보험",
        "desc": "런당 첫 폐기 택배의 페널티 무효"
      },
      "tent": {
        "name": "천막",
        "desc": "비·태풍에도 야외 택배가 젖지 않음"
      },
      "breath": {
        "name": "심호흡",
        "desc": "월초에 스트레스 -1"
      },
      "overtime": {
        "name": "연장 근무",
        "desc": "기한 초과 택배의 보상 감소 25% → 10%"
      },
      "foresight": {
        "name": "예지",
        "desc": "입고 예정을 4턴까지 표시"
      },
      "emergency": {
        "name": "비상 대응",
        "desc": "긴급 특송 계약 -30%, 매월 마켓에 긴급 특송 등장"
      },
      "regulars": {
        "name": "정기 고객",
        "desc": "일반 택배 보상 +5"
      },
      "premium": {
        "name": "프리미엄 서비스",
        "desc": "특수 운송 보너스 +5"
      },
      "closing": {
        "name": "월말 결산",
        "desc": "월말 창고 사용률 60% 이하면 +60"
      },
      "consult": {
        "name": "물류 컨설팅",
        "desc": "신뢰도 경험치 획득 +1"
      },
      "taxsave": {
        "name": "절세",
        "desc": "월말 운영비 -20"
      },
      "investor": {
        "name": "투자 유치",
        "desc": "시작 자금 +150, 월말 운영비 +20"
      }
    },
    "PERK_FAMILIES": {
      "contract": "계약",
      "warehouse": "창고",
      "ops": "운영",
      "income": "수익"
    },
    "DAILY_VARIANTS": {
      "fog": {
        "name": "안개",
        "desc": "입고 예정 표시 1턴"
      },
      "express": {
        "name": "급행",
        "desc": "모든 기한 -1턴, 보상 +10"
      },
      "bigweek": {
        "name": "대형 주간",
        "desc": "크기 4 이상 비율 2배"
      },
      "inflation": {
        "name": "물가 상승",
        "desc": "마켓 가격 ×1.3, 보상 +10%"
      },
      "trustboom": {
        "name": "신뢰 붐",
        "desc": "신뢰도 경험치 ×2"
      },
      "repair": {
        "name": "창고 정비",
        "desc": "시작 용량 -4, 창고 확장 -50%"
      },
      "picky": {
        "name": "깐깐한 고객",
        "desc": "기한 초과 시 보상 -50%"
      },
      "generous": {
        "name": "후한 고객",
        "desc": "회당 3개 이상 처리 시 보상 +15%"
      }
    },
    "SCENARIOS": {
      "standard": {
        "name": "표준 3개월",
        "desc": "기본 규칙. 3개월 생존",
        "win": "3개월 생존",
        "recommend": "동네 택배"
      },
      "half": {
        "name": "반기 결산",
        "desc": "6개월 풀런. 전문·마스터 등급, 대형화물 등장",
        "win": "6개월 생존 (점수 ×1.5)",
        "recommend": "국영 우편"
      },
      "peak": {
        "name": "성수기",
        "desc": "입고 ×2.0, 폭주 턴 5회(폭주 입고분 기한 -2), 반송 유예 2턴. 보상 +10, 가격 ×1.3, 시작 호출 +2",
        "win": "2개월 생존 + 42개 처리",
        "recommend": "도심 퀵 · 강철 창고"
      },
      "heatwave": {
        "name": "폭염",
        "desc": "신선 비율 +20%p, 상온 부패 3배, 폭염 경보 턴(월 3회), 입고 +10%",
        "win": "3개월 생존 + 폐기 3개 이하",
        "recommend": "프레시 로지스틱스"
      },
      "strike": {
        "name": "파업",
        "desc": "매월 운송 업체 1종 호출 불가 (월초 공지). 입고 +20%, 운영비 +30. 긴급 특송 상시 등장",
        "win": "3개월 생존",
        "recommend": "스타트업"
      },
      "port": {
        "name": "항만 계약",
        "desc": "통관 20%·대형 12%, 초대형 7%, 입고 +10%. 통관·대형 보상 +20, 일반 -5",
        "win": "4개월 생존",
        "recommend": "글로벌 · 강철 창고"
      },
      "cashcrunch": {
        "name": "자금난",
        "desc": "시작 자금 -50%, 운영비 240, 새로고침 불가, 마켓 가격 +10%. 수익 +10%, 신뢰도 ×2",
        "win": "3개월 생존 + 자금 600 이상",
        "recommend": "짠돌이 · 국영 우편"
      },
      "blackfriday": {
        "name": "블랙 프라이데이",
        "desc": "한 달 지옥. 입고 ×2.3, 폭주 턴 4회, 가격 ×1.4, 반송 유예 4턴. 보상 +15, 시작 호출 +3",
        "win": "1개월 생존 + 22개 처리",
        "recommend": "도심 퀵 · 짠돌이"
      },
      "audit": {
        "name": "감사",
        "desc": "모든 기한 -1턴, 기한 초과 보상 -50%, 월초 스트레스 +1, 운영비 +30",
        "win": "3개월 생존 + 기한 초과 처리 4개 이하",
        "recommend": "국영 우편 · 유리방"
      },
      "moving": {
        "name": "이사철",
        "desc": "이사센터 포함, 보관 제안 5턴마다 보장, 보관료 ×1.5. 봄 날씨",
        "win": "3개월 생존 + 보관 계약 6건 완수",
        "recommend": "강철 창고"
      },
      "bigdeal": {
        "name": "대형 계약",
        "desc": "고객 1명(무작위)이 물량 60%. 배상 ×1.2",
        "win": "3개월 생존 + 그 고객 신뢰 3단계",
        "recommend": "도심 퀵"
      },
      "endless": {
        "name": "무한 운영",
        "desc": "게임오버까지. 7개월차부터 매월 입고 +1, 12개월차부터 운영비 +10/월",
        "win": "없음 — 점수 경쟁",
        "recommend": "—"
      },
      "daily": {
        "name": "데일리 배송",
        "desc": "날짜 시드 고정 + 변형 규칙 2개. 회사는 그날 지정",
        "win": "3개월 생존 (하루 1회 기록)",
        "recommend": "그날 지정"
      }
    },
    "ACHIEVEMENTS": {
      "rookie": {
        "name": "신입 기사",
        "desc": "런 3회 플레이 (승패 무관)"
      },
      "two_clears": {
        "name": "두 번째 성공",
        "desc": "아무 시나리오나 2회 클리어"
      },
      "fresh30": {
        "name": "신선 서른",
        "desc": "신선식품 누적 30개 처리"
      },
      "fragile30": {
        "name": "파손주의 서른",
        "desc": "파손주의 누적 30개 처리"
      },
      "worldwide": {
        "name": "세계로",
        "desc": "통관 화물 누적 30개 처리"
      },
      "big20": {
        "name": "무거운 손",
        "desc": "크기 4 이상 택배 누적 20개를 기한 내 처리"
      },
      "three_companies": {
        "name": "세 회사의 사장",
        "desc": "서로 다른 회사 3개로 런 클리어"
      },
      "fresh_king": {
        "name": "신선 배송왕",
        "desc": "한 런에서 신선식품 15개를 부패 없이 처리"
      },
      "giant": {
        "name": "거인의 어깨",
        "desc": "한 런에서 초대형(7) 택배 5개를 기한 내 처리"
      },
      "nonstop": {
        "name": "무정차",
        "desc": "대기 없이 30턴 연속 배송(직접 배송한 대기 턴 포함)"
      },
      "unbreakable": {
        "name": "깨지지 않는",
        "desc": "한 런에서 파손주의 12개를 기한 내 처리"
      },
      "patience": {
        "name": "기다림의 미학",
        "desc": "월평균 호출 4회 이하로 런 클리어"
      },
      "cust_l3": {
        "name": "단골",
        "desc": "한 런에서 고객 신뢰 3단계 달성"
      },
      "storage3": {
        "name": "창고 대여업",
        "desc": "보관 계약 누적 3건 완수"
      },
      "noclaim2": {
        "name": "무사고",
        "desc": "보험 청구 0건으로 2개월 연속"
      },
      "snowrun": {
        "name": "눈길 배송",
        "desc": "폭설 턴에 신선 택배 5개 처리"
      },
      "landlord": {
        "name": "집주인",
        "desc": "이사철 클리어"
      },
      "partner": {
        "name": "파트너",
        "desc": "대형 계약 클리어"
      },
      "veteran_clear": {
        "name": "베테랑",
        "desc": "베테랑 난이도로 클리어"
      },
      "first_clear": {
        "name": "첫 클리어",
        "desc": "아무 시나리오나 클리어"
      },
      "busy_month": {
        "name": "바쁜 달",
        "desc": "한 달에 15개 이상 처리"
      },
      "peak_clear": {
        "name": "성수기 정복",
        "desc": "성수기 클리어"
      },
      "fresh20": {
        "name": "신선 스무 개",
        "desc": "신선식품 누적 20개 처리"
      },
      "four_carriers": {
        "name": "네 업체",
        "desc": "계약 슬롯 4개를 서로 다른 업체로 채우고 클리어"
      },
      "intl15": {
        "name": "통관 열다섯",
        "desc": "통관 화물 누적 15개 처리"
      },
      "rich_clear": {
        "name": "부자 클리어",
        "desc": "자금 1,000 이상으로 표준 3개월 클리어"
      },
      "half_clear": {
        "name": "반기 클리어",
        "desc": "반기 결산 클리어"
      },
      "three_unlocked": {
        "name": "세 회사",
        "desc": "회사 3개 해금"
      },
      "veteran": {
        "name": "베테랑",
        "desc": "회사 5개 해금"
      },
      "buyer": {
        "name": "단골 손님",
        "desc": "계약 누적 10개 구매"
      },
      "fresh_start": {
        "name": "과감한 교체",
        "desc": "잔여 호출 3회 이상인 계약을 교체하고 클리어"
      },
      "trust3": {
        "name": "신뢰의 정점",
        "desc": "한 업체를 신뢰 3단계까지 올림"
      },
      "empty_tank": {
        "name": "빈 탱크",
        "desc": "잔여 호출 0인 계약 4개로 월말을 맞고 생존"
      },
      "big_haul": {
        "name": "한 방",
        "desc": "한 호출로 6개 이상 처리"
      },
      "no_spoil": {
        "name": "무부패",
        "desc": "신선식품 부패 0회로 클리어"
      },
      "overflow_survivor": {
        "name": "넘쳐도 산다",
        "desc": "창고 초과 상태로 5턴 이상 버티고 클리어"
      },
      "expander": {
        "name": "확장주의자",
        "desc": "한 런에 창고 확장 2개 구매"
      },
      "cold_buyer": {
        "name": "냉장 투자",
        "desc": "냉장고 증설 2회 구매한 런 클리어"
      },
      "xl_stack": {
        "name": "초대형 삼총사",
        "desc": "초대형 3개를 동시에 보관"
      },
      "survivor": {
        "name": "벼랑 끝",
        "desc": "스트레스 15 이상에서 클리어"
      },
      "late_but_done": {
        "name": "늦어도 배송",
        "desc": "기한 초과 택배 10개를 처리하고 클리어"
      },
      "waiter": {
        "name": "기다리는 자",
        "desc": "대기 누적 40회"
      },
      "clutch": {
        "name": "클러치",
        "desc": "긴급 특송으로 부패 직전 신선식품 처리"
      },
      "normal100": {
        "name": "일반 백 개",
        "desc": "일반 택배 누적 100개"
      },
      "all_special": {
        "name": "만능 물류",
        "desc": "특수 택배 4종을 한 런에서 모두 전문 업체로 처리"
      },
      "tidy": {
        "name": "깔끔한 마감",
        "desc": "월말 사용률 40% 이하로 월 마감 3회 (누적)"
      },
      "trusted_three": {
        "name": "신뢰 삼각",
        "desc": "신뢰 2단계 업체 3개"
      },
      "rich": {
        "name": "여유 자금",
        "desc": "자금 1,500 이상으로 클리어"
      },
      "broke": {
        "name": "간당간당",
        "desc": "자금 100 이하로 월말을 넘기고 클리어"
      },
      "perfect_month": {
        "name": "완벽한 달",
        "desc": "페널티 0으로 한 달 마감"
      },
      "full_house": {
        "name": "만석",
        "desc": "창고 사용률 100% 이상에서 페널티 없이 다음 턴"
      },
      "big_hand": {
        "name": "큰 손",
        "desc": "한 호출로 8개 처리"
      },
      "master_deal": {
        "name": "마스터 계약",
        "desc": "마스터 등급 계약 보유"
      },
      "trust_badge": {
        "name": "신뢰의 증표",
        "desc": "신뢰 3단계 업체 2개"
      },
      "millionaire": {
        "name": "백만장자",
        "desc": "자금 2,000"
      },
      "all_companies": {
        "name": "전 회사 클리어",
        "desc": "9개 회사 모두 표준 클리어"
      },
      "all_scenarios": {
        "name": "전 시나리오 클리어",
        "desc": "무한 운영 제외 10개 클리어"
      },
      "daily7": {
        "name": "데일리 7일",
        "desc": "데일리 7일 연속 클리어"
      }
    }
  },
  };
  if (typeof module !== 'undefined') module.exports = L; else (root.LOCALES = root.LOCALES || {}).ko = L;
})(typeof window !== 'undefined' ? window : globalThis);
